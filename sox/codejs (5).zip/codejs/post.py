#!/usr/bin/env python3
import json
import os
import random
import re
import urllib.parse
import requests

# Apnar Apps Script Web App URL
WEB_APP_URL = "https://script.google.com/macros/s/AKfycbz5JTThC7OKvh_bnhU2sqKzshcd-40k0i2nYsZ1_mYKZjXgLA0BNMJGbHILvcURq9eshw/exec"

# Target landing page redirection
TARGET_URL = "https://vrfeeds.com/ai/?sz"

# Resource files directory
RESOURCE_DIR = "resource_files"

def read_lines(filename, fallback_list):
    filepath = os.path.join(RESOURCE_DIR, filename)
    if os.path.exists(filepath):
        with open(filepath, "r", encoding="utf-8") as f:
            lines = [line.strip() for line in f if line.strip()]
            if lines:
                return lines
    return fallback_list

def load_all_resources():
    keywords = read_lines("keywords.txt", [
        "Lionel Messi Farewell Match",
        "Croatia vs Spain",
        "Bulgaria vs Luxembourg",
        "England vs Czechia",
        "France v Belgium"
    ])
    
    images = read_lines("images.txt", [
        "https://cdn.pixabay.com/photo/2015/06/24/02/12/the-blurred-819385_640.jpg",
        "https://cdn.pixabay.com/photo/2015/06/24/02/12/the-blurred-819385_640.jpg",
        "https://cdn.pixabay.com/photo/2015/06/24/02/12/the-blurred-819385_640.jpg"
    ])
    
    patterns = read_lines("patterns.txt", [
        "live-on-free-today-match-en-gb9001-83",
        "match-live-free-ontv-0-0-0-0-0-0-1-643",
        "today-74",
        "uefa-friendly-match-stream-hd"
    ])
    
    scripts = read_lines("scripts.txt", [
        "https://vrfeeds.com/java/scm.js",
        "https://vrfeeds.com/java/scm.js",
        "https://vrfeeds.com/java/scm.js"
    ])
    
    tag1_list = read_lines("tag1.txt", [
        "",
        "",
        ""
    ])
    
    tag2_list = read_lines("tag2.txt", [
        "",
        "",
        ""
    ])
    
    return keywords, images, patterns, scripts, tag1_list, tag2_list

def slugify(text):
    text = text.lower()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-")

def main():
    if not os.path.exists(RESOURCE_DIR):
        os.makedirs(RESOURCE_DIR)
        print(f"[*] Folder '{RESOURCE_DIR}' toiri kora hoyeche.")

    keywords, images, patterns, scripts, tag1_list, tag2_list = load_all_resources()

    print(f"[*] Total Resources Loaded:")
    print(f"    - Keywords : {len(keywords)}")
    print(f"    - Images   : {len(images)}")
    print(f"    - Patterns : {len(patterns)}")
    print(f"    - Scripts  : {len(scripts)}")
    print(f"    - Tag1     : {len(tag1_list)}")
    print(f"    - Tag2     : {len(tag2_list)}")

    pages_to_save = []
    generated_urls = []

    for kw in keywords:
        pattern = random.choice(patterns)
        slug = f"{slugify(kw)}-{pattern}"
        
        # Link structure exact ?vmc=slug
        article_url = f"{WEB_APP_URL}?vmc={urllib.parse.quote(slug)}"
        generated_urls.append(article_url)

        pages_to_save.append({
            "keyword": kw,
            "slug": slug,
            "tag1": random.choice(tag1_list),
            "tag2": random.choice(tag2_list),
            "targetUrl": TARGET_URL,
            "image": random.choice(images),
            "scriptUrl": random.choice(scripts)
        })

    with open("sports_articles.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(generated_urls))
    print(f"\n[+] Total {len(generated_urls)} links saved to 'sports_articles.txt'")

    batch_size = 25
    session = requests.Session()
    print("[*] Uploading pages to Google Apps Script...")

    for i in range(0, len(pages_to_save), batch_size):
        chunk = pages_to_save[i:i + batch_size]
        payload = {"action": "savePages", "pages": chunk}
        try:
            res = session.post(
                WEB_APP_URL,
                data=json.dumps(payload),
                headers={"Content-Type": "text/plain"},
                timeout=60
            )
            print(f"[+] Batch {i // batch_size + 1} synced ({len(chunk)} articles).")
        except Exception as e:
            print(f"[-] Batch {i // batch_size + 1} failed: {e}")

    print("\n[✔] Shob kisu success! Ekhon video player Google Search-e thik screen shot-er moto Play Button shoho Video Snippet hishebe ashbe.")

if __name__ == "__main__":
    main()