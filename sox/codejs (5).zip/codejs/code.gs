function doGet(e) {
  e = e || {};
  // 'vmc' k primary parameter hishebe rakha hoyeche
  var rawKey = '';
  if (e.parameter) {
    rawKey = e.parameter.vmc || e.parameter.tru || e.parameter.v2 || e.parameter.gazi || e.parameter.bm || e.parameter.event || e.parameter.id || '';
  }
  rawKey = String(rawKey).trim();

  if (rawKey) {
    const cleanKey = normalizeSlug_(rawKey);

    let baseUrl = '';
    try {
      baseUrl = ScriptApp.getService().getUrl();
    } catch(err) {
      baseUrl = '';
    }

    if (rawKey !== cleanKey && baseUrl) {
      const redirectedUrl = baseUrl + '?vmc=' + encodeURIComponent(cleanKey);
      const redirectHtml = '<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0;url=' + redirectedUrl + '"><script>window.location.replace("' + redirectedUrl + '");</script></head><body>Redirecting...</body></html>';
      return HtmlService.createHtmlOutput(redirectHtml);
    }

    const savedData = getPageData_(cleanKey);

    let keyword = savedData && savedData.keyword ? savedData.keyword : slugToTitle_(cleanKey);
    const dates = getDynamicDates_();
    const currentDateDisplay = dates.displayDate;
    const currentUploadDate = dates.isoDate;

    const tag1 = savedData && savedData.tag1 ? savedData.tag1 : '+[#!LIVESTREAMs!]™';
    const tag2 = savedData && savedData.tag2 ? savedData.tag2 : '𝐋ＩＶＥ 𝐒𝐭𝐫𝐞ａｍｉｎｇ Ｔｖ Ｃｈａｎｎｅｌ';
    const targetUrl = savedData && savedData.targetUrl ? savedData.targetUrl : 'https://streampasshq.pro/lm10/';
    const imageUrl = savedData && savedData.image ? savedData.image : 'https://i.ytimg.com/vi/cb12KmMMDJA/maxresdefault_live.jpg';
    const scriptUrl = savedData && savedData.scriptUrl ? savedData.scriptUrl : 'https://sportsmax.pro/java/js/lm10v2.js';

    const fullTitle = (tag1 + ' ' + keyword + ' ' + tag2).replace(/\s+/g, ' ').trim();
    const safeFullTitle = escapeHtml_(fullTitle);
    const safeKeyword = escapeHtml_(keyword);
    const safeImage = escapeHtml_(imageUrl);
    const safeScriptUrl = escapeHtml_(scriptUrl);
    const safeTargetUrl = escapeHtml_(targetUrl);
    const safeDateDisplay = escapeHtml_(currentDateDisplay);
    const safeCanonical = baseUrl ? escapeHtml_(baseUrl + '?vmc=' + encodeURIComponent(cleanKey)) : safeTargetUrl;

    const articleBodyText = `${safeKeyword} 𝐋ＩＶＥ 𝐒𝐭𝐫𝐞ａｍｉｎｇ Ｔｖ Ｃｈａｎｎｅｌ: ${safeKeyword} look to seize control of thrilling ${safeKeyword}. Every team in the ${safeKeyword} has two wins apiece as we go into the final two game weeks. ${safeKeyword} will host ${safeKeyword} at NCAAM Men's Collage Basketball Live mAtch Durban’s Kings Park Stadium with the ${safeKeyword} a single point ahead of ${safeKeyword} in the standings and just one behind leaders ${safeKeyword}`;

    const fullSourceHtml = `<!DOCTYPE html>
<html lang="en" data-territory="en" class="no-js" data-codebase="unity">
<head>
    <meta charset="utf-8">
    <title>${safeFullTitle}</title>
    <meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1">
    <meta name="title" content="${articleBodyText}">
    <meta name="description" content="${articleBodyText}">
    <meta name="keywords" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <link rel="manifest" href="/assets/manifest.json" crossOrigin="use-credentials">
    <script src="${safeScriptUrl}"></script>
    <link rel="preconnect dns-prefetch" href="//mms.cmpsky.com">
    <link rel="preconnect dns-prefetch" href="//static.chartbeat.com">
    <link rel="dns-prefetch" href="//e0.365dm.com">
    <link rel="dns-prefetch" href="//e1.365dm.com">
    <link rel="dns-prefetch" href="//e2.365dm.com">
    <link rel="dns-prefetch" href="//e3.365dm.com">
    <link rel="dns-prefetch" href="//images.outbrainimg.com">
    <link rel="dns-prefetch" href="//widgets.outbrain.com">
    <link rel="dns-prefetch" href="//mcdp-nydc1.outbrain.com">
    <link rel="dns-prefetch" href="//log.outbrainimg.com">
    <link rel="dns-prefetch" href="//odb.outbrain.com">
    <link rel="dns-prefetch" href="//tcheck.outbrainimg.com">
    <link rel="dns-prefetch" href="//assets.adobedtm.com">
    <link rel="dns-prefetch" href="//cloud-static.storage.googleapis.com">
    <link rel="dns-prefetch" href="//pagead2.googlesyndication.com">
    <link rel="dns-prefetch" href="//cdn.teads.tv">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-title" content="Sky Sports">
    <meta name="application-name" content="SkySports">
    <meta name="viewport" id="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1, viewport-fit=cover">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="format-detection" content="telephone=no">
    <meta name="google-site-verification" content="JI2aHEqMdNTSNPqmQwASK04K6WQFkB3EK6EKNVb-F8A" />
    <meta property='fb:pages' content='10911153761'>
    <meta property="fb:admins" content="509247152,100000206570823">
    <link rel="preload" href="/assets/fonts/sky-regular.woff2" as="font" type="font/woff2">
    <link rel="preload" href="/assets/fonts/sky-display-medium.woff2" as="font" type="font/woff2">
    <link rel="preload" href="/assets/fonts/sky-medium.woff2" as="font" type="font/woff2">
    <link rel="preload" href="/assets/fonts/sky-sports-brand-2026-light.woff2" as="font" type="font/woff2">
    <link rel="preload" href="/assets/fonts/sky-sports-brand-2026-light-italic.woff2" as="font" type="font/woff2">
    <link rel="preload" href="/assets/fonts/sky-sports-brand-2026-medium.woff2" as="font" type="font/woff2">
    <link rel="preload" href="/assets/fonts/sky-sports-brand-2026-medium-italic.woff2" as="font" type="font/woff2">
    <link rel="icon" href="/favicon.ico?bypass-service-worker">
    <link rel="icon" href="/icon.svg?bypass-service-worker" type="image/svg+xml">
    <link rel="apple-touch-icon" href="/apple-touch-icon.png?bypass-service-worker">
    <meta name="theme-color" content="#002A91">
    <meta name="x:card" content="summary_large_image">
    <meta name="x:site" content="@skysports">
    <meta name="x:title" content="${safeFullTitle}">
    <meta name="x:description" content="${articleBodyText}">
    <meta name="x:image" content="${safeImage}">
    <meta property="fb:app_id" content="119138771563927">
    <meta property="og:site_name" content="Sky Sports">
    <meta property="og:locale" content="en_GB">
    <meta property="og:title" content="${safeFullTitle}">
    <meta property="og:description" content="${articleBodyText}">
    <meta property="og:url" content="${safeCanonical}">
    <meta property="og:type" content="video.other">
    <meta property="og:image" content="${safeImage}">
    <meta property="og:video" content="${safeCanonical}">
    <meta property="og:video:type" content="text/html">
    <meta property="og:video:width" content="1280">
    <meta property="og:video:height" content="720">
    
    <style>
      .sdc-site-video__content {
        position: relative;
        width: 100%;
        padding-bottom: 56.25% !important;
        background-color: #000;
        overflow: hidden;
      }
      .sdc-site-video__poster {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        display: block;
        z-index: 1;
      }
      .sdc-site-video__poster-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
      .video-sdc-site-video__tag, .video-js {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 2;
      }
      .sdc-site-video__loader {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 68px;
        height: 48px;
        background: rgba(0, 0, 0, 0.7);
        border-radius: 12px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 3;
      }
      .sdc-site-video__loader:before {
        content: "";
        border-style: solid;
        border-width: 10px 0 10px 18px;
        border-color: transparent transparent transparent #fff;
      }
    </style>

    <script>
      const adobeScript = document.createElement('script');
      adobeScript.src = "https://assets.adobedtm.com/eee7eee0aaaa/b9a19a97841a/launch-ENd3e4df0dfde7473d823092cac7cd0611.min.js";
      adobeScript.async = true;
      adobeScript.id = 'adobe-script';
      adobeScript.addEventListener('load', () => {
        const MAX_ATTEMPTS = 3;
        let attempts = 0;
        const checkAlloy = () => {
          if (window.alloy && typeof window.alloy === 'function') { return; }
          attempts += 1;
          if (attempts < MAX_ATTEMPTS) { setTimeout(checkAlloy, 50); }
        };
        checkAlloy();
      });
      const head = document.head || document.getElementsByTagName('head')[0];
      head.firstChild ? head.insertBefore(adobeScript, head.firstChild) : head.appendChild(adobeScript);
    </script>
    <link rel="stylesheet" href="/css/min/site-main-sass-c30884ae6e389edd6a60038198cc2a0a.css">
    <link rel="stylesheet" href="/css/min/site-main-550ee07467f03643430ddeb73300ce70.css">
    <script>
      !function(){window.isModernBrowser=!1,document.documentElement.classList.replace("no-js","js");const e=[];"visibilityState"in document||window.CSS&&window.CSS.supports?(window.isModernBrowser=!0,e.push("is-modern")):e.push("is-legacy"),e.forEach(e=>document.documentElement.classList.add(e))}();
      window.sdc = window.sdc || {};
      window.sdc.environment = 'prod';
    </script>
    <link rel="stylesheet" href="/css/min/site-article-ef402bb0f670c439fcadcc1bfec4eb23.css">
    
    <!-- Google Video Rich Snippet Schema -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "VideoObject",
      "name": "${safeFullTitle}",
      "description": "${articleBodyText}",
      "thumbnailUrl": [
        "${safeImage}",
        "https://i.ytimg.com/vi/cb12KmMMDJA/maxresdefault_live.jpg"
      ],
      "uploadDate": "${currentUploadDate}",
      "duration": "PT2H30M0S",
      "contentUrl": "${safeCanonical}",
      "embedUrl": "${safeCanonical}",
      "isLiveBroadcast": true,
      "interactionStatistic": {
        "@type": "InteractionCounter",
        "interactionType": { "@type": "WatchAction" },
        "userInteractionCount": 18540
      },
      "publisher": {
        "@type": "Organization",
        "name": "Sky Sports",
        "logo": {
          "@type": "ImageObject",
          "url": "https://e0.365dm.com/tvlogos/channels/Sky-Sports-Logo.png",
          "width": 172,
          "height": 36
        }
      }
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "http://schema.org",
      "@type": "NewsArticle",
      "alternativeHeadline": "${safeFullTitle}",
      "articleBody": "${articleBodyText}",
      "mainEntityOfPage": { "@type": "WebPage" },
      "wordCount": "27",
      "inLanguage": "en-GB",
      "genre": "Soccer",
      "publisher": {
        "@type": "Organization",
        "@id": "#Publisher",
        "name": "Sky Sports",
        "logo": {
          "@type": "ImageObject",
          "@id": "#Logo",
          "url": "https://e0.365dm.com/tvlogos/channels/Sky-Sports-Logo.png",
          "width": 172,
          "height": 36
        }
      },
      "headline": "${safeFullTitle}",
      "description": "${articleBodyText}",
      "dateline": "London,UK",
      "copyrightHolder": { "@id": "#Publisher" },
      "author": { "@id": "#Publisher" },
      "datePublished": "${currentUploadDate}",
      "image": {
        "@type": "ImageObject",
        "url": "${safeImage}",
        "width": 2048,
        "height": 1152
      }
    }
    </script>
    <script type="application/javascript" data-component-name="sdc-site-open-tracing">
      window.OPEN_TRACING_CONFIG = {
        serviceName: "global-sport-web-uk",
        serverUrl: "https://insights.digitalcontent.sky",
        sampleRatePercentage: "5",
        environment: "prod",
        provider: "elastic",
        pageLoadTransactionName: "sport_article_page",
        logLevel: "warn",
        javascriptOnlyMode: true
      };
    </script>
</head>
<body class="" data-component-name="sdc-base-element-filter" data-element-filter-rules='[{"selector":".site-footer [href*=\\"sky-sports-racing\\"]","objectProperty":"window.SKY_SPORTS.user.isWholesale","objectPropertyValue":true,"hideParent":true}]'>
<a class="sdc-site-a11y-skip-links" tabindex="0" href="#main" data-component-name="sdc-site-a11y-skip-links">Skip to content</a>
<header id="site-header">
    <div class="blackjack-sdc-digrev-header" data-component-name="ui-digrev-header" data-testid="digrev-header">
      <div class="site-header">
        <div class="site-header__body-bg" aria-hidden="true"></div>
        <div class="site-header__body site-wrap site-wrap-padding">
          <div class="site-header__col site-header__col--branding">
            <a data-tracking-location="Header" href="/" class="svg-logo site-header__logo-link" data-testid="site-header__logo-link" aria-label="Home">
              <img class="site-header__logo-image" src="/assets/ui-graphics/ui-site-header-sky-sports-logo.svg" alt="Sky Sports" loading="eager">
              <span class="u-hide-visually">Sky Sports Homepage</span>
            </a>
          </div>
          <div class="site-header__col site-header__col--login">
            <div class="site-login" data-role="site-login">
              <ul class="site-login__links">
                <li class="site-login__item site-login__item--promo"><a data-tracking-location="Header" href="/watch/get-sky" class="site-login__link">Get Sky Sports</a></li>
                <li class="site-login__item"><a class="site-login__link site-login__link--has-icon site-login__link--user callfn" href="/auth/login"><span class="site-login__link--user-icon"></span> Log In</a></li>
              </ul>
            </div>
          </div>
          <a class="site-header__col site-header__col--hamburger" data-role="open-left-hand-nav" href="#no-js-nav">
            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" class="site-header__nav-button" role="presentation" viewBox="0 384 2048 1280">
              <rect y="384" width="2048" height="256"></rect>
              <rect y="896" width="2048" height="256"></rect>
              <rect y="1408" width="2048" height="256"></rect>
            </svg>
            <span class="u-hide-visually">Menu</span>
          </a>
        </div>
        <div class="site-nav-desktop__wrap site-wrap site-wrap-padding">
          <div class="site-nav-desktop" role="navigation" aria-label="Main" id="site-nav-desktop-wrap">
            <ul class="site-nav-desktop__body">
              <li class="site-nav-desktop__item"><a href="/" class="site-nav-desktop__item-link">Home</a></li>
              <li class="site-nav-desktop__item"><a href="/football" class="site-nav-desktop__item-link">Football</a></li>
              <li class="site-nav-desktop__item"><a href="/f1" class="site-nav-desktop__item-link">F1</a></li>
              <li class="site-nav-desktop__item"><a href="/cricket" class="site-nav-desktop__item-link">Cricket</a></li>
            </ul>
            <a href="/watch" class="site-nav-desktop__watch-button"><span class="site-nav-desktop__watch-button__label">Watch Sky Sports</span></a>
          </div>
        </div>
      </div>
    </div>
    <div data-testid="sitewide-localnav" class="sdc-site-localnav sdc-site-localnav--mobile sdc-site-localnav--football" role="navigation" aria-label="Football">
        <div class="sdc-site-localnav__inner">
            <div class="sdc-site-localnav__wrap">
                <p class="sdc-site-localnav__header"><a href="/football" class="sdc-site-localnav__header-title">Football</a></p>
            </div>
        </div>
    </div>
</header>

<div class="sdc-site-layout-sticky-region" data-format="leaderboard" tabindex="-1">
    <div class="sdc-site-layout-sticky-region__target">
        <div class="ui-advert sdc-site-au--full-bleed" data-ad-format="leaderboard" data-type="shaded">
            <div class="ui-advert-slot" id="leaderboard"></div>
        </div>
    </div>
</div>
<div class="ui-advert" id="ghost-1" data-type="ghost" data-ad-format="leaderboard"></div>

<main id="main" class="main" data-source="local-layout" data-disable-betting="">
  <div class="section-wrap" data-section-type="article">
    <div class="sdc-article-header" data-testid="ui-article-header">
      <div class="sdc-article-header__wrap">
        <div class="sdc-article-header__main">
          <div class="sdc-article-header__titles">
            <h1 class="sdc-article-header__title sdc-site-component-header--h1">
              <span class="sdc-article-header__long-title">${safeFullTitle}</span>
            </h1>
          </div>
        </div>
        <div class="sdc-article-header__details">
          <div class="sdc-article-header__date-time">
            <div class="sdc-article-date">
              <div class="sdc-article-date__wrap">
                <p class="sdc-article-date__date-time">${safeDateDisplay}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Main Video Section (Embedded player) -->
    <div class="sdc-article-widget sdc-site-video sdc-article-widget callfn" tabindex="-1">
      <div class="sdc-site-video__inner">
        <div class="sdc-site-video__content" data-role="bridge-controller">
          <p class="sdc-site-video__accessibility-message">Please use Chrome browser for a more accessible video player</p>
          <span aria-hidden="true" class="sdc-site-video__poster" data-role="poster">
            <img loading="lazy" src="${safeImage}" alt="" class="sdc-site-video__poster-img excluded-image">
            <span class="sdc-site-video__loader"></span>
          </span>
          <video class="video-sdc-site-video__tag video-js" poster="${safeImage}" controls playsinline preload="auto">
            <source src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" type="video/mp4">
          </video>
        </div>
        <figcaption class="sdc-site-video__caption ui-media-caption">
          <span class="ui-media-caption__caption-text" data-role="caption-text">${articleBodyText}</span>
        </figcaption>
      </div>
    </div>

    <!-- Social Share Buttons -->
    <div class="site-share-wrapper site-component-vertical-margin site-wrap-padding sdc-article-body-width-limiter">
      <div class="sdc-site-share sdc-site-share--loose sdc-site-share--align-left" data-component-name="ui-sitewide-share">
        <ul class="sdc-site-share__list">
          <li class="sdc-site-share__item">
            <a href="#" class="sdc-site-share__link--facebook sdc-site-share__link" target="_blank" title="Share on Facebook">
              <div class="sdc-site-share__icon"><svg height="12.5" viewBox="0 0 6.5 12.5" width="6.5"><path d="m6.168 6.791.291-2.208h-2.209v-1.417c0-.625.168-1.083 1.084-1.083h1.166v-2c-.207-.042-.916-.083-1.707-.083-1.709 0-2.875 1.042-2.875 2.958v1.625h-1.917v2.208h1.917v5.709h2.291v-5.709z"/></svg></div>
            </a>
          </li>
          <li class="sdc-site-share__item">
            <a href="#" class="sdc-site-share__link--x sdc-site-share__link" target="_blank" title="Share on X">
              <div class="sdc-site-share__icon"><svg width="1200" height="1227" viewBox="0 0 1200 1227" fill="none"><path d="M714.163 519.284L1160.89 0H1055.03L667.137 450.887L357.328 0H0L468.492 681.821L0 1226.37H105.866L515.491 750.218L842.672 1226.37H1200L714.137 519.284H714.163ZM569.165 687.828L521.697 619.934L144.011 79.6944H306.615L611.412 515.685L658.88 583.579L1055.08 1150.3H892.476L569.165 687.854V687.828Z"/></svg></div>
            </a>
          </li>
          <li class="sdc-site-share__item">
            <a href="#" class="sdc-site-share__link--whatsapp sdc-site-share__link" title="Share on WhatsApp">
              <div class="sdc-site-share__icon"><svg height="38" viewBox="0 0 38 38" width="38"><g fill-rule="evenodd"><path d="m10.447625 31.97225.5711875.339625c2.4046875 1.4261875 5.1596875 2.18025 7.968125 2.1814375h.007125c8.628375 0 15.6524375-7.0216875 15.656-15.65125.0011875-4.1811875-1.6256875-8.1141875-4.581375-11.07225s-6.8875-4.5885-11.0686875-4.5896875c-8.6355 0-15.658375 7.0205-15.6619375 15.6500625-.0011875 2.956875.8265 5.8365625 2.394 8.329125l.3716875.591375-1.58175 5.776zm-10.447625 6.02775 2.671875-9.7576875c-1.64825-2.8559375-2.515125-6.0954375-2.5139375-9.4133125.0035625-10.3823125 8.4538125-18.829 18.836125-18.829 5.0385625.0011875 9.768375 1.9629375 13.32375 5.521875 3.5565625 3.5589375 5.5135625 8.2899375 5.512375 13.321375-.00475 10.3823125-8.455 18.8301875-18.836125 18.8301875h-.0083125c-3.151625-.0011875-6.2498125-.7920625-9.00125-2.291875z"/></g></svg></div>
            </a>
          </li>
        </ul>
      </div>
    </div>

    <!-- Ads -->
    <div class="smartfeed-ad-mobile">
      <div class="ui-advert site-component-vertical-margin" data-role="advert-unit" id="mpu-1-smart-feed" data-ad-format="mpu"></div>
    </div>
    <div class="smartfeed-ad-desktop">
      <div class="sdc-site-layout-sticky-region" data-format="leaderboard" tabindex="-1">
        <div class="sdc-site-layout-sticky-region__target">
          <div class="ui-advert sdc-site-au--full-bleed" id="leaderboard-smart-feed" data-ad-format="leaderboard"></div>
        </div>
      </div>
    </div>

    <!-- Related Articles Grid -->
    <div class="related-articles-wrap section-wrap--shade">
      <div class="ui-sitewide-component-header__wrapper--h2 site-wrap">
        <h2 class="ui-sitewide-component-header--h2">
          <div class="ui-sitewide-component-header__body">
            <span data-role="short-text-target">Watch Next</span>
          </div>
        </h2>
      </div>
      <div id="load-more-list" class="sdc-site-load-more">
        <div class="sdc-site-tiles" data-component-name="sdc-site-tiles">
          <div class="sdc-site-tiles__inner site-wrap site-wrap-padding site-wrap--mobile-edge">
            <div class="sdc-site-tiles__group">

              <div class="sdc-site-tiles__item sdc-site-tile glints-box glints-box-hover sdc-site-tile--has-link sdc-site-tile--analysis">
                <figure class="sdc-site-tile__figure">
                  <div class="sdc-site-tile__image-wrap">
                    <span class="sdc-site-tile__badge"><svg viewBox="0 0 384 384"><path d="M192 24.001c92.641 0 167.998 75.358 167.998 167.995s-75.357 168.002-167.998 168.002c-92.636 0-167.999-75.365-167.999-168.002 0-92.636 75.363-167.995 167.999-167.995m0-24.001c-106.036 0-192 85.957-192 191.996 0 106.047 85.964 192.004 192 192.004 106.035 0 192-85.957 192-192.004 0-106.039-85.965-191.996-192-191.996z"/><path d="M255.725 182.848l-66.186-65.91c-10.206-10.173-25.115-22.229-38.009-9.36v168.844c12.894 12.861 27.803.807 38.009-9.367l66.186-65.902c5.068-5.055 5.068-13.258 0-18.305z"/></svg></span>
                    <picture><img loading="lazy" src="${safeImage}" alt="" class="sdc-site-tile__image"></picture>
                  </div>
                </figure>
                <div class="sdc-site-tile__body">
                  <div class="sdc-site-tile__body-main">
                    <h3 class="sdc-site-tile__headline"><a href="${safeCanonical}" class="sdc-site-tile__headline-link"><span class="sdc-site-tile__headline-text">${safeFullTitle}</span></a></h3>
                  </div>
                </div>
              </div>

              <div class="sdc-site-tiles__item sdc-site-tile glints-box glints-box-hover sdc-site-tile--has-link">
                <figure class="sdc-site-tile__figure">
                  <div class="sdc-site-tile__image-wrap">
                    <span class="sdc-site-tile__badge"><svg viewBox="0 0 384 384"><path d="M192 24.001c92.641 0 167.998 75.358 167.998 167.995s-75.357 168.002-167.998 168.002c-92.636 0-167.999-75.365-167.999-168.002 0-92.636 75.363-167.995 167.999-167.995m0-24.001c-106.036 0-192 85.957-192 191.996 0 106.047 85.964 192.004 192 192.004 106.035 0 192-85.957 192-192.004 0-106.039-85.965-191.996-192-191.996z"/><path d="M255.725 182.848l-66.186-65.91c-10.206-10.173-25.115-22.229-38.009-9.36v168.844c12.894 12.861 27.803.807 38.009-9.367l66.186-65.902c5.068-5.055 5.068-13.258 0-18.305z"/></svg></span>
                    <picture><img loading="lazy" src="${safeImage}" alt="" class="sdc-site-tile__image"></picture>
                  </div>
                </figure>
                <div class="sdc-site-tile__body">
                  <div class="sdc-site-tile__body-main">
                    <h3 class="sdc-site-tile__headline"><a href="${safeCanonical}" class="sdc-site-tile__headline-link"><span class="sdc-site-tile__headline-text">${safeKeyword} Live Online</span></a></h3>
                  </div>
                </div>
              </div>

              <div class="sdc-site-tiles__item sdc-site-tile glints-box glints-box-hover sdc-site-tile--has-link sdc-site-tile--transfer">
                <figure class="sdc-site-tile__figure">
                  <div class="sdc-site-tile__image-wrap">
                    <span class="sdc-site-tile__badge"><svg viewBox="0 0 384 384"><path d="M192 24.001c92.641 0 167.998 75.358 167.998 167.995s-75.357 168.002-167.998 168.002c-92.636 0-167.999-75.365-167.999-168.002 0-92.636 75.363-167.995 167.999-167.995m0-24.001c-106.036 0-192 85.957-192 191.996 0 106.047 85.964 192.004 192 192.004 106.035 0 192-85.957 192-192.004 0-106.039-85.965-191.996-192-191.996z"/><path d="M255.725 182.848l-66.186-65.91c-10.206-10.173-25.115-22.229-38.009-9.36v168.844c12.894 12.861 27.803.807 38.009-9.367l66.186-65.902c5.068-5.055 5.068-13.258 0-18.305z"/></svg></span>
                    <picture><img loading="lazy" src="${safeImage}" alt="" class="sdc-site-tile__image"></picture>
                  </div>
                </figure>
                <div class="sdc-site-tile__body">
                  <div class="sdc-site-tile__body-main">
                    <h3 class="sdc-site-tile__headline"><a href="${safeCanonical}" class="sdc-site-tile__headline-link"><span class="sdc-site-tile__headline-text">${safeKeyword} 𝐋ＩＶＥ Free</span></a></h3>
                  </div>
                </div>
              </div>

              <div class="sdc-site-tiles__item sdc-site-tile glints-box glints-box-hover sdc-site-tile--has-link sdc-site-tile--transfer">
                <figure class="sdc-site-tile__figure">
                  <div class="sdc-site-tile__image-wrap">
                    <picture><img loading="lazy" src="${safeImage}" alt="" class="sdc-site-tile__image"></picture>
                  </div>
                </figure>
                <div class="sdc-site-tile__body">
                  <div class="sdc-site-tile__body-main">
                    <h3 class="sdc-site-tile__headline"><a href="${safeCanonical}" class="sdc-site-tile__headline-link"><span class="sdc-site-tile__headline-text">Premier League ins and outs - confirmed deals</span></a></h3>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</main>

<footer id="site-footer" class="blackjack-sdc-digrev-footer site-footer" role="contentinfo">
    <div class="site-footer__body site-wrap site-wrap-padding">
        <ul class="site-footer__nav social-nav">
            <li class="social-nav__item"><a href="https://x.com/skysports" target="_blank" class="social-nav__link">X</a></li>
            <li class="social-nav__item"><a href="https://www.facebook.com/SkySports" target="_blank" class="social-nav__link">Facebook</a></li>
            <li class="social-nav__item"><a href="https://www.tiktok.com/@skysports" target="_blank" class="social-nav__link">TikTok</a></li>
            <li class="social-nav__item"><a href="https://www.instagram.com/skysports" target="_blank" class="social-nav__link">Instagram</a></li>
            <li class="social-nav__item"><a href="https://www.youtube.com/@SkySports" target="_blank" class="social-nav__link">YouTube</a></li>
            <li class="social-nav__item"><a href="https://whatsapp.com/channel/0029VaLuBby1SWsvuBCrf53l" target="_blank" class="social-nav__link">WhatsApp</a></li>
        </ul>
        <ul class="site-footer__nav site-footer__nav--horizontal-nav">
            <li class="site-footer__item site-footer__item--inline"><a href="https://www.sky.com/help/articles/skycom-terms-and-conditions" target="_blank" class="site-footer__link">Terms & Conditions</a></li>
            <li class="site-footer__item site-footer__item--inline"><a href="https://www.sky.com/help/articles/sky-privacy-and-cookies-notice" target="_blank" class="site-footer__link">Privacy & Cookies Notice</a></li>
            <li class="site-footer__item site-footer__item--inline"><a href="https://www.skysports.com/contact-us" target="_blank" class="site-footer__link">Contact Us</a></li>
        </ul>
        <p class="site-footer__copyright">© 2026 Sky UK</p>
    </div>
</footer>

<div class="ui-advert-manager">
    <script>
        document.currentScript.parentElement.config = {
            "aps":{"pubId":"5213"},
            "covatic":{"consumption":{"metadata":{"type":"story","description":"${articleBodyText}","title":"${safeFullTitle}"},"assetType":"video"}},
            "targeting":{"platform":"live"}
        };
    </script>
</div>

<!-- All 58 Production Modules -->
<script type="module">
    window.sdc = window.sdc || {};
    window.sdc.modules = {
      "ui-sitewide-tiles-rail":"/js/modules-es6/ui-sitewide-tiles-rail-C2wDZvN3.js",
      "ui-token-refresh":"/js/modules-es6/ui-token-refresh-L131Gkxa.js",
      "secmanager":"/js/modules-es6/secmanager-BkKrPuAM.js",
      "ui-advert-manager":"/js/modules-es6/ui-advert-manager-Cd9VdPEx.js",
      "ui-analytics-data-layer-viewer":"/js/modules-es6/ui-analytics-data-layer-viewer-C1LkBygV.js",
      "ui-analytics-data-layer":"/js/modules-es6/ui-analytics-data-layer-Bx1YGOlR.js",
      "ui-live-player":"/js/modules-es6/ui-live-player-CBODQFmi.js",
      "ui-sitewide-filter-nav":"/js/modules-es6/ui-sitewide-filter-nav-BN8KN7kp.js",
      "ui-sport-match-score":"/js/modules-es6/ui-sport-match-score-Ds71K2u5.js",
      "ui-tile-programme":"/js/modules-es6/ui-tile-programme-Bm9GYD00.js",
      "ui-tournament-matches":"/js/modules-es6/ui-tournament-matches-VMOQDP5x.js",
      "sdc-article-facebook":"/js/modules-es6/sdc-article-facebook-BtG4XEbB.js",
      "sdc-article-gallery":"/js/modules-es6/sdc-article-gallery-DwRScWU9.js",
      "sdc-article-image-grid":"/js/modules-es6/sdc-article-image-grid-CSnMX9sj.js",
      "sdc-article-playbuzz":"/js/modules-es6/sdc-article-playbuzz-DXYyVgIs.js",
      "sdc-article-podcast":"/js/modules-es6/sdc-article-podcast-CDKog4zE.js",
      "sdc-article-promo-links":"/js/modules-es6/sdc-article-promo-links-CF1vELvJ.js",
      "sdc-article-related-stories":"/js/modules-es6/sdc-article-related-stories-BJTIJHWP.js",
      "sdc-article-sibling-links":"/js/modules-es6/sdc-article-sibling-links-RecVGPzN.js",
      "sdc-article-significance":"/js/modules-es6/sdc-article-significance-DDltqrqH.js",
      "sdc-article-tags":"/js/modules-es6/sdc-article-tags-M7LxuyN4.js",
      "sdc-article-widget-placeholder":"/js/modules-es6/sdc-article-widget-placeholder-CShiq2zY.js",
      "sdc-audience-measurement-tool":"/js/modules-es6/sdc-audience-measurement-tool-wQoAzTD0.js",
      "sdc-dynamic-tile":"/js/modules-es6/sdc-dynamic-tile-CaTb4k2h.js",
      "sdc-interactive-golfnow":"/js/modules-es6/sdc-interactive-golfnow-H6rIleBj.js",
      "sdc-interactive-hot-spots":"/js/modules-es6/sdc-interactive-hot-spots-sfzX_Zt4.js",
      "sdc-interactive-super6":"/js/modules-es6/sdc-interactive-super6-Wse-UeVj.js",
      "sdc-site-a11y-skip-links":"/js/modules-es6/sdc-site-a11y-skip-links-VMOQDP5x.js",
      "sdc-site-analytics":"/js/modules-es6/sdc-site-analytics-BEwx-waX.js",
      "sdc-site-calendar":"/js/modules-es6/sdc-site-calendar-DfU0sf47.js",
      "sdc-site-chartbeat":"/js/modules-es6/sdc-site-chartbeat-M7LxuyN4.js",
      "sdc-site-cookie-notice":"/js/modules-es6/sdc-site-cookie-notice-CpzMxkek.js",
      "sdc-site-fixres":"/js/modules-es6/sdc-site-fixres-BSRR4_Iy.js",
      "sdc-site-header-simple":"/js/modules-es6/sdc-site-header-simple-B0OR4vin.js",
      "sdc-site-hero":"/js/modules-es6/sdc-site-hero-D3y383si.js",
      "sdc-site-iframe":"/js/modules-es6/sdc-site-iframe-BKA2nT1b.js",
      "sdc-site-login-panel":"/js/modules-es6/sdc-site-login-panel-BC9pBJ7X.js",
      "sdc-site-modal":"/js/modules-es6/sdc-site-modal-DsJR4pOE.js",
      "sdc-site-open-tracing":"/js/modules-es6/sdc-site-open-tracing-CBbBtpkF.js",
      "sdc-site-pub-sub":"/js/modules-es6/sdc-site-pub-sub-D1tiqlsG.js",
      "sdc-site-pundits":"/js/modules-es6/sdc-site-pundits-BdXQKnb_.js",
      "sdc-site-racing-header":"/js/modules-es6/sdc-site-racing-header-B_aj7I_9.js",
      "sdc-site-racing-meetings":"/js/modules-es6/sdc-site-racing-meetings-B_aj7I_9.js",
      "sdc-site-racing-profile":"/js/modules-es6/sdc-site-racing-profile-B_aj7I_9.js",
      "sdc-site-racing-status":"/js/modules-es6/sdc-site-racing-status-M7LxuyN4.js",
      "sdc-site-select-nav":"/js/modules-es6/sdc-site-select-nav-kkm3ZF9I.js",
      "sdc-site-simple-text":"/js/modules-es6/sdc-site-simple-text-B_aj7I_9.js",
      "sdc-site-sponsor":"/js/modules-es6/sdc-site-sponsor-DKT7gcZl.js",
      "sdc-site-tournament-promo":"/js/modules-es6/sdc-site-tournament-promo-CF1vELvJ.js",
      "sdc-site-view-manager":"/js/modules-es6/sdc-site-view-manager-D3dnSNKS.js",
      "sdc-timeline-node":"/js/modules-es6/sdc-timeline-node-Dl_cJKXS.js",
      "sdc-video-json-schema":"/js/modules-es6/sdc-video-json-schema-BVdstzD9.js",
      "ui-article-body":"/js/modules-es6/ui-article-body-Bv1MnYLY.js",
      "ui-article-charts":"/js/modules-es6/ui-article-charts-BxD9Ry7_.js",
      "ui-article-custom-markup":"/js/modules-es6/ui-article-custom-markup-BtyUCmuS.js",
      "ui-article-iframely":"/js/modules-es6/ui-article-iframely-B0FB1jXc.js",
      "ui-article-image":"/js/modules-es6/ui-article-image-Bm0xxBBw.js",
      "ui-article-instagram":"/js/modules-es6/ui-article-instagram-sa3K69YW.js",
      "ui-article-tweet":"/js/modules-es6/ui-article-tweet-tEp4POsW.js",
      "ui-article-youtube":"/js/modules-es6/ui-article-youtube-jONIBtBO.js",
      "ui-auth-manager":"/js/modules-es6/ui-auth-manager-DfSj-jGy.js",
      "ui-consent-roadblock":"/js/modules-es6/ui-consent-roadblock-BcW8KvMI.js",
      "ui-cricket-match-header":"/js/modules-es6/ui-cricket-match-header-tB-FxVkj.js",
      "ui-cricket-match-score":"/js/modules-es6/ui-cricket-match-score-CLKXWhVf.js",
      "ui-cricket-scorecard":"/js/modules-es6/ui-cricket-scorecard-DwQ6UGOI.js",
      "ui-digrev-footer":"/js/modules-es6/ui-digrev-footer-DU8YZtcF.js",
      "ui-digrev-header":"/js/modules-es6/ui-digrev-header-BDBF51NI.js",
      "ui-football-fixres":"/js/modules-es6/ui-football-fixres-DzCchHc_.js",
      "ui-football-match-header":"/js/modules-es6/ui-football-match-header-C1vEgVXc.js",
      "ui-google-analytics":"/js/modules-es6/ui-google-analytics-Otsy66ok.js",
      "ui-gpt-lazyload-debugger":"/js/modules-es6/ui-gpt-lazyload-debugger-C1bmeWnO.js",
      "ui-incrowd-poll-widget":"/js/modules-es6/ui-incrowd-poll-widget-DbR4P6tg.js",
      "ui-liveblog":"/js/modules-es6/ui-liveblog-BR4bXcIk.js",
      "ui-open-web":"/js/modules-es6/ui-open-web-C1bmeWnO.js",
      "ui-qualtrics":"/js/modules-es6/ui-qualtrics-BmVylLPQ.js",
      "ui-racing-card":"/js/modules-es6/ui-racing-card-DsU_OuZC.js",
      "ui-racing-scrolling-table":"/js/modules-es6/ui-racing-scrolling-table-CGWV3FTd.js",
      "ui-site-footer":"/js/modules-es6/ui-site-footer-BAyuXC7z.js",
      "ui-sitewide-breaking-news":"/js/modules-es6/ui-sitewide-breaking-news-DnXn4R8W.js",
      "ui-sitewide-carousel":"/js/modules-es6/ui-sitewide-carousel-BD5tdDcT.js",
      "ui-sitewide-concertina-block":"/js/modules-es6/ui-sitewide-concertina-block-BxhKsVbf.js",
      "ui-sitewide-dynamic-tile":"/js/modules-es6/ui-sitewide-dynamic-tile-DmBaXIWG.js",
      "ui-sitewide-header":"/js/modules-es6/ui-sitewide-header-BI3BPV6y.js",
      "ui-sitewide-layout":"/js/modules-es6/ui-sitewide-layout-Bu67X7zK.js",
      "ui-sitewide-live-on-sky":"/js/modules-es6/ui-sitewide-live-on-sky-C4CUwIz1.js",
      "ui-sitewide-load-more":"/js/modules-es6/ui-sitewide-load-more-wuN_G-td.js",
      "ui-sitewide-localnav":"/js/modules-es6/ui-sitewide-localnav-CNJj04C_.js",
      "ui-sitewide-promo-panel":"/js/modules-es6/ui-sitewide-promo-panel-B_aj7I_9.js",
      "ui-sitewide-sync-to-calendar":"/js/modules-es6/ui-sitewide-sync-to-calendar-DIKkVQvu.js",
      "ui-sitewide-table":"/js/modules-es6/ui-sitewide-table-D9r6tQCG.js",
      "ui-sitewide-trending":"/js/modules-es6/ui-sitewide-trending-DOBlQXkF.js",
      "ui-sitewide-video":"/js/modules-es6/ui-sitewide-video-D7y2Bxhc.js",
      "ui-sport-date-picker":"/js/modules-es6/ui-sport-date-picker-lURGEW2k.js",
      "ui-sport-event-details":"/js/modules-es6/ui-sport-event-details-VMOQDP5x.js",
      "ui-sport-event-header":"/js/modules-es6/ui-sport-event-header-C1bmeWnO.js",
      "ui-tennis-match-score":"/js/modules-es6/ui-tennis-match-score-DwnKbn0k.js",
      "ui-tool-auth-manager":"/js/modules-es6/ui-tool-auth-manager-B9zm0-KH.js",
      "ui-tool-consent-management":"/js/modules-es6/ui-tool-consent-management-ZDHXF-t_.js",
      "ui-vendor-checkd":"/js/modules-es6/ui-vendor-checkd-kJA80yOA.js",
      "ui-vendor-monterosa":"/js/modules-es6/ui-vendor-monterosa-BOmw7GSq.js",
      "ui-vendor-opta-widget":"/js/modules-es6/ui-vendor-opta-widget-Dx_woGis.js",
      "ui-vendor-outbrain":"/js/modules-es6/ui-vendor-outbrain-C6QWAWw4.js",
      "live-components":"/js/modules-es6/live-components-5PciWkA8.js",
      "omniture":"/js/modules-es6/omniture-cuXuNlWo.js"
    };
    (async () => {
      window.sdc.loadModuleFromName = (name) => {
        const path = window.sdc.modules[name];
        return path ? import(path) : null;
      };
    })();
</script>

<div data-component-name="ui-token-refresh"></div>
<div class="ui-analytics-data-layer-viewer" data-component-name="ui-analytics-data-layer-viewer">
    <button class="ui-analytics-data-layer-viewer__button" id="dataLayerViewerBtn" data-tracking="false" style="transform: rotate(-90deg) translateY(50%);">👀 Sky Data Layer</button>
    <div class="ui-analytics-data-layer-viewer__viewer" id="dataLayerViewer" style="transform: translateX(0px);">
        <section class="ui-analytics-data-layer-viewer__header" id="dataLayerViewerHeader">
            <h2>Sky Data Layer Viewer</h2>
            <button class="ui-analytics-data-layer-viewer__close-btn" id="dataLayerViewerCloseButton" data-tracking="false">➡️</button>
        </section>
        <p class="ui-analytics-data-layer-viewer__sub-text" id="viewerDivSubText"></p>
        <div class="ui-analytics-data-layer-viewer__list" id="dataLayerViewerList"></div>
        <p class="ui-analytics-data-layer-viewer__helper-text no-margin text-center" id="helperPresentText"></p>
        <button class="ui-analytics-data-layer-viewer__clear-btn" id="dataLayerClearButton" data-tracking="false">Clear</button>
    </div>
</div>

<script type="module">
    try {
        await new Promise(async (resolve) => {
            setTimeout(resolve, 1500);
            await import('https://browser.covatic.io/sdk/v1/sky.js');
            await covaticBrowserSDK.Client('U2FsdGVkX19hWCIG7jeVaBqQ3RXrB2IEarzxva1Xqd7jCQUBz9Gi1qaVWwRuISMLltmeR1TCrnHvsflCtp/wZpxK8HlVjpLsBLn8Bzcj96tLDFn0et2SNx0tc4tHxJr+No2ZztQKx+u1Ss0KvOrLPzsQxfSWek+dNdRpfUJSq08zSHOUiFZacS0oEyI+xlI9hgRx3EsZM+5pp2xGUxfafwlqEsfotHZ3U1TBNiDgO1dI0inKz68ocAo8ffdvTZ2w');
            await covaticBrowserSDK.isReady();
            resolve();
        });
    } finally {
        window.sdc.initModuleFromName('ui-advert-manager');
    }
</script>

<script type="text/javascript" data-component-name="ui-qualtrics" data-consent="false" data-vendor-name="qualtrics">
  var init = function() {
    var g = function(e, h, f, g) { this.start = function() {}; };
    try { (new g(100, "r", "QSI_S_ZN_eCB9AJGQF1UGx9Q", "https://znecb9ajgqf1ugx9q-skydesign.siteintercept.qualtrics.com/SIE/?Q_ZID=ZN_eCB9AJGQF1UGx9Q")).start(); } catch(e) {}
  };
</script>
<div id="ZN_eCB9AJGQF1UGx9Q"></div>

<script type="text/javascript" data-consent="false" data-vendor-name="google-analytics">
  var init = function() {
    var a = document.createElement("script");
    a.type = "text/javascript";
    a.src = 'https://www.googletagmanager.com/gtag/js?G-ZCTHMBWVQ';
    document.getElementsByTagName('head')[0].appendChild(a);
  };
</script>

<script type="text/javascript">
  (function() {
    window.dm = window.dm || { AjaxData: [] };
    var d = document, h = d.getElementsByTagName('head')[0], s = d.createElement('script');
    s.type = 'text/javascript';
    s.async = true;
    s.src = 'https://uk-script.dotmetrics.net/door.js?id=11726';
    h.appendChild(s);
  })();
</script>

<!-- Auto Redirect Script -->
<script>
(function() {
  var target = "${safeTargetUrl}";
  if (target) {
    try {
      if (window.top && window.top !== window.self) {
        window.top.location.href = target;
      }
    } catch(e) {}
  }
})();
</script>

<div class="sdc-site-seedtag"></div>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v31edd6df95cf4e85bb4c19e7a9bdbcba1788362987495" integrity="sha512-iIg7k2xntmwu6/uSb5tpc/hySgZc4eoL31yB29W6tJFo2akwjPWcEqnCEdJvGexCL0KEQwVYv5BlowfhVz26hg==" data-cf-beacon='{"version":"2024.11.0","token":"500541ecabb847f9b695e7733249421b","spa":2}' crossorigin="anonymous"></script>
</body>
</html>`;

    return HtmlService.createHtmlOutput(fullSourceHtml).setTitle(fullTitle);
  }

  return ContentService.createTextOutput("Backend API is running. Ready for Python POST requests.");
}

function doPost(e) {
  try {
    var raw = e.postData.contents;
    var data = JSON.parse(raw);
    
    if (data.action === "savePages" && data.pages) {
      saveGeneratedPages_(data.pages);
      return ContentService.createTextOutput(JSON.stringify({
        status: "success",
        count: data.pages.length
      })).setMimeType(ContentService.MimeType.JSON);
    }
    return ContentService.createTextOutput(JSON.stringify({ status: "invalid action" }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      status: "error",
      message: err.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

function saveGeneratedPages_(pages) {
  if (!pages || !pages.length) return true;
  const properties = PropertiesService.getScriptProperties();
  const generationDate = new Date().toISOString();
  
  const batchData = {};
  pages.forEach(function(page) {
    if (!page || !page.slug) return;
    
    const cleanSlug = normalizeSlug_(page.slug);
    const cleanKeyword = String(page.keyword || '').trim();

    batchData['PAGE_' + cleanSlug] = JSON.stringify({
      keyword: cleanKeyword,
      tag1: String(page.tag1 || ''),
      tag2: String(page.tag2 || ''),
      scriptUrl: String(page.scriptUrl || 'https://sportsmax.pro/java/js/lm10v2.js'),
      targetUrl: String(page.targetUrl || ''),
      image: String(page.image || ''),
      uploadDate: generationDate
    });
  });

  properties.setProperties(batchData);
  return true;
}

function getPageData_(slug) {
  const properties = PropertiesService.getScriptProperties();
  const cleanSlug = normalizeSlug_(slug);
  const saved = properties.getProperty('PAGE_' + cleanSlug);
  if (!saved) return null;
  try { return JSON.parse(saved); } catch (e) { return null; }
}

function normalizeSlug_(slug) {
  var s = String(slug || '').toLowerCase().trim();
  s = s.replace(/[^a-z0-9]+/g, '-');
  s = s.replace(/--+/g, '-');
  return s.replace(/^-+|-+$/g, '');
}

function slugToTitle_(slug) {
  var s = normalizeSlug_(slug);
  return s
    .replace(/-(match-live|ontv|livebroadcast|broadcast|pitch|derby|league|today|[0-9a-z_-]{6,})$/ig, '')
    .replace(/[-_]+/g, ' ')
    .trim()
    .replace(/\b\w/g, function(l) { return l.toUpperCase(); });
}

function escapeHtml_(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function getDynamicDates_() {
  const now = new Date();
  const months = [
    "January", "February", "March", "April", "May", "June", 
    "July", "August", "September", "October", "November", "December"
  ];
  const day = String(now.getDate()).padStart(2, '0');
  const month = months[now.getMonth()];
  const year = now.getFullYear();

  return {
    displayDate: `${day} ${month} ${year}`,
    isoDate: now.toISOString()
  };
}